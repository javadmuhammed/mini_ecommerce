

let mongoose = require("mongoose");


let db = mongoose.connect("mongodb://127.0.0.1/mini_ecommerce");

db.then(function () {
    console.log("Database connected successfull");
}).catch(function () {
    console.log("Database connection failed");
})


module.exports = db;




