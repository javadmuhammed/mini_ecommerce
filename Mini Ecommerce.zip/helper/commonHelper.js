
let productModel = require("../model/common/productModel")
let UserModel = require("../model/userModel/userModel")
const util = require('util');
let path = require("path");
const userCollction = require("../model/userModel/userModel");


let commonHelper = {


    getAllProductAggregate: async function(query)
    {
        console.log(query) // [ { '$sort': { price: 1 } } ]
        let data = await productModel.aggregate(query).exec()
        return data;
    },


    getAllProduct: async function (query) {
        let data = await productModel.find(query).exec();
        return data;
    },

    getLimitedProduct: async function (req, limit) {
        let filtter = {};
        if (req.query.status) {
            filtter["status"] = (req.query.status == "active") ? "UNBLOCK" : "BLOCK";
        }
        console.log(filtter);
        let data = await productModel.find(filtter).limit(limit).exec();
        return data;
    },


    addNewUser: async function (userObject, files) {
        console.log("Level 1");
        return new Promise(function (resolve, reject) {
            files.mv(path.join(__dirname, "../public/user_profile/" + userObject.dp), async function (err, data) {
                if (err) {
                    reject()
                } else {
                    let user = new UserModel(userObject);
                    let saveUser = await user.save()
                    resolve(saveUser);
                }
            })
        })
    },

    

    getSingleUser: function (user_id) {
        return new Promise(function (resolve, reject) {
            userCollction.findById(user_id).then(function (data) {
                resolve(data)
            }).catch(function (err) {
                reject(err)
            })
        })
    }
}


module.exports = commonHelper;